package com.example.projekt_zaliczeniowy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjektZaliczeniowyApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjektZaliczeniowyApplication.class, args);
	}

}
