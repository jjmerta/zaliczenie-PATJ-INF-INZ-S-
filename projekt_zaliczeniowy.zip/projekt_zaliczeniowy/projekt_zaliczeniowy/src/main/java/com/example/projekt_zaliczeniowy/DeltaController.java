package com.example.projekt_zaliczeniowy;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class DeltaController {
    @GetMapping("/delta")
    public String deltaForm(Model model) {
        model.addAttribute("delta", new Delta());
        return "delta";
    }

    @PostMapping("/delta")
    public String deltaSubmit(@ModelAttribute Delta delta, Model model) {
        delta.setDelta(delta.obliczDelte(delta.getWartoscA(), delta.getWartoscB(), delta.getWartoscC()));
        delta.setPierwszeRozwiazanie(delta.obliczPierwszeRozwiazanie(delta.getWartoscB(), delta.getWartoscA(), delta.obliczPierwiastekDelta(delta.getDelta())));
        delta.setDrugieRozwiazanie(delta.obliczDrugieRozwiazanie(delta.getWartoscB(), delta.getWartoscA(), delta.obliczPierwiastekDelta((delta.getDelta()))));

        model.addAttribute("delta", delta);
        return "result";
    }
}