package com.example.projekt_zaliczeniowy;

import java.lang.Math;
public class Delta {
    private double wartoscA;
    private double wartoscB;
    private double wartoscC;
    private double delta;
    private double pierwiastekDelta;
    private double pierwszeRozwiazanie;
    private double drugieRozwiazanie;


    //GETTERY
    public double getWartoscA() {
        return wartoscA;
    }
    public double getWartoscB() {
        return wartoscB;
    }
    public double getWartoscC() {
        return wartoscC;
    }
    public double getDelta() {
        return delta;
    }
    public double getPierwiastekDelta() {
        return pierwiastekDelta;
    }
    public double getPierwszeRozwiazanie() {
        return pierwszeRozwiazanie;
    }
    public double getDrugieRozwiazanie() {
        return drugieRozwiazanie;
    }

    //SETTERY
    public void setWartoscA(double wartoscA) {
        this.wartoscA = wartoscA;
    }
    public void setWartoscB(double wartoscB) {
        this.wartoscB = wartoscB;
    }
    public void setWartoscC(double wartoscC) {
        this.wartoscC = wartoscC;
    }
    public void setDelta(double delta) {
        this.delta = delta;
    }
    public void setPierwiastekDelta(double pierwiastekDelta) {
        this.pierwiastekDelta = pierwiastekDelta;
    }
    public void setPierwszeRozwiazanie(double pierwszeRozwiazanie) {
        this.pierwszeRozwiazanie = pierwszeRozwiazanie;
    }
    public void setDrugieRozwiazanie(double drugieRozwiazanie) {
        this.drugieRozwiazanie = drugieRozwiazanie;
    }

    //b2−4ac
    public double obliczDelte(double wartoscA, double wartoscB, double wartoscC) {
        return (Math.pow(wartoscB, 2) - 4 * (wartoscA * wartoscC));
    }

    public double obliczPierwiastekDelta(double delta){
        return(Math.sqrt(delta));
    }

    public double obliczPierwszeRozwiazanie(double wartoscB, double wartoscA, double pierwiastekDelta){
        return((-wartoscB - pierwiastekDelta)/(2*wartoscA));
    }
    public double obliczDrugieRozwiazanie(double wartoscB, double wartoscA, double pierwiastekDelta){
        return((-wartoscB + pierwiastekDelta)/(2*wartoscA));
    }
}
